function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6oORaGo6sov":
        Script1();
        break;
      case "5uMrveLX1sY":
        Script2();
        break;
      case "5hnQKfbELNr":
        Script3();
        break;
  }
}

function Script1()
{
  initMetacog();
}

function Script2()
{
  logEvent1();
}

function Script3()
{
  logEvent2();
}

