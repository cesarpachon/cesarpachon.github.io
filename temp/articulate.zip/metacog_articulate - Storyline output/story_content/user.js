function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ZqRJmF5zc2":
        Script1();
        break;
      case "6hHgeXnSUUo":
        Script2();
        break;
      case "6BKkfaQ4q27":
        Script3();
        break;
  }
}

function Script1()
{
  initMetacog();
}

function Script2()
{
  logEvent1();
}

function Script3()
{
  logEvent2();
}

