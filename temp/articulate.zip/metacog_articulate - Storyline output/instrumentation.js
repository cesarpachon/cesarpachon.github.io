function initMetacog(){
  console.log("initMetacog..");
  Metacog.init({
      "session": {
          "publisher_id": '9d10ead1', //provided to you as part of Metacog API Credentials
          "application_id": 'c7f16e0b559f05489e2b900f52f08a99', //provided to you as part of Metacog API Credentials
          "widget_id": 'articulate_integration'
      },
      log_tab: true,
      mode:"production"
  }, function(){
    console.log("metacog is ready!"); 
    Metacog.start();
  });
};


function logEvent1(){
  Metacog.send({
    event: 'event1', 
    data:{}, 
    type:Metacog.EVENT_TYPE.MODEL
  }); 
};


function logEvent2(){
  Metacog.send({
    event: 'event2', 
    data:{}, 
    type:Metacog.EVENT_TYPE.MODEL
  });
};
